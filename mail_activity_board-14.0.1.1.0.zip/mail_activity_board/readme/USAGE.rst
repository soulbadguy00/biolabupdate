To use this module, you need to:

#. Access to the views from menu Boards.

A smartButton of activities is added in the mail thread from form view.
From this smartButton is linked to the activity board, to the view tree,
which shows the activities related to the opportunity.

From the form view of the activity you can navigate to the origin of the activity.
